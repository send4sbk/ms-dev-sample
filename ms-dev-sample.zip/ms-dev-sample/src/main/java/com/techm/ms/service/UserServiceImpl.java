package com.techm.ms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.techm.ms.exception.CustomUserException;
import com.techm.ms.exception.CustomUserNotFoundException;
import com.techm.ms.model.User;

@Service
public class UserServiceImpl implements UserService {
	static List<User> userLst = new ArrayList<User>();
	static {
		userLst.add(new User(1L, "josh", 28, 12345));
		userLst.add(new User(2L, "josh", 28, 125));
		userLst.add(new User(3L, "josh", 28, 1345));
		userLst.add(new User(4L, "josh", 28, 1455));
	}

	@Override
	public User createUser(User user) {

		for (User usr : userLst) {
			if (usr.getId() == user.getId())
			{
				throw new CustomUserException("User already exists, the id is:"+user.getId());
			}
		}

		userLst.add(user);

		return user;
	}

	@Override
	public User findUSer(long id) {
		
		for (User usr : userLst) {
			if (usr.getId() == id)
			{
				return usr;
			}else {
				throw new CustomUserNotFoundException("User not found in Lst ");
			}
			
		}
		return null;
	}

}
