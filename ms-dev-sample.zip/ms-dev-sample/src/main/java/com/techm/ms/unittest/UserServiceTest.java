package com.techm.ms.unittest;

import static org.junit.Assert.assertEquals;

import org.aspectj.lang.annotation.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.techm.ms.model.User;
import com.techm.ms.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserServiceTest {

	private UserService UserServiceImpl;

	@BeforeClass
	public void setup() throws Exception {
       
		UserServiceImpl=new com.techm.ms.service.UserServiceImpl();
	}

	@Test(expected = RuntimeException.class)
	public void createUsrAlreadyExistTest() {
		User user = new User(1L, "josh", 28, 12345);
		User existingUser = UserServiceImpl.createUser(user);
		assertEquals(user, existingUser);
	}

	@Test
	public void createUserTest() {
		User user = new User(6L, "Danny", 28, 55545);
		User existingUser = UserServiceImpl.createUser(user);
		assertEquals(user, existingUser);
	}

	@Test
	public void findUserTest() {

		User user = new User(1L, "josh", 28, 12345);
		User existingUser = UserServiceImpl.findUSer(user.getId());
		assertEquals(user.getId(), existingUser.getId());
	}

	@Test(expected = RuntimeException.class)
	public void userNotFountTest() {

		User user = new User(6L, "Danny", 28, 55545);
		User existingUser = UserServiceImpl.findUSer(user.getId());
		assertEquals(user.getId(), existingUser.getId());
	}

}
