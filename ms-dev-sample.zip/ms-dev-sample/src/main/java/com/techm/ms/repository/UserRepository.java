package com.techm.ms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.techm.ms.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
	
}
