package com.techm.ms.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.techm.ms.model.User;
import com.techm.ms.service.UserService;

@RestController
public class UserResourceImpl implements UserResource {
	
	@Autowired
	private UserService userServiceImpl;
	
	@PostMapping(path="/createUser")
	public User createUserAccount(@RequestBody User user) {
		User usr=userServiceImpl.createUser(user);
		return usr;
	}
	
	@GetMapping(path="/finduser/{id}")
	public User findOneUser(@PathVariable int id) {
		User existingUser=userServiceImpl.findUSer(id);
		return existingUser;
	}
}
