package com.techm.ms.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value= org.springframework.http.HttpStatus.CONFLICT)
public class CustomUserException extends RuntimeException{

	public CustomUserException(String message) {
		super(message);
	}
	
}
