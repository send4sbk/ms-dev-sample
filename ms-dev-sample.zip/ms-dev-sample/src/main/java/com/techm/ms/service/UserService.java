package com.techm.ms.service;

import com.techm.ms.model.User;

public interface UserService {

	public User createUser(User user);
	public User findUSer(long id);
}
