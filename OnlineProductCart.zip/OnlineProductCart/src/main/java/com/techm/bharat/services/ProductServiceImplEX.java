package com.techm.bharat.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.techm.bharat.beans.Product;
import com.techm.bharat.exceptions.CustomSystemException;


public class ProductServiceImplEX {

	private static List<Product> productLst = new ArrayList<Product>();
	//private static List<String> relatedItemsLst = new ArrayList<String>();

	static {
		//relatedItemsLst.add("item1");
		//relatedItemsLst.add("item2");

		productLst.add(new Product(new Integer(123), "222", "del laptop", "static/image/1.jpg", new BigDecimal(1600.00),
				"laptop"));
		productLst.add(new Product(new Integer(124), "333", "del laptop", "static/image/1.jpg", new BigDecimal(444.00),
				"ipad"));
		productLst.add(new Product(new Integer(125), "4444", "del laptop", "static/image/1.jpg", new BigDecimal(333.00),
				"tabs"));
		productLst.add(new Product(new Integer(126), "5555", "del laptop", "static/image/1.jpg", new BigDecimal(999.00),
				"iphones"));

	}

	public Iterable<Product> listAllProducts() {
		return productLst;
	}

	public Product getProductById(Integer id) {
		for (Product product : productLst) {
			if (product.getId() == id) {
				return product;
			}
		}
		return null;
	}

	public Product saveProduct(Product product) {
		for (Product prodt : productLst) {
			if (product.getId() == prodt.getId()) {
				throw new CustomSystemException("prodcut already exists in the system" + product.getId());
			}
		}
		productLst.add(product);
		return product;
	}

	public void deleteProduct(Integer id) {
		Iterator<Product> itr = productLst.iterator();

		while (itr.hasNext()) {
			Product prd = (Product) itr.next();
			if (prd.getId() == id) {
				itr.remove();
			}
		}

	}

	/*
	 * public Product editById(int id) {
	 * 
	 * for (Product product : productLst) { if (product.getProductId() == id) {
	 * return product; } } return null; }
	 */

}
