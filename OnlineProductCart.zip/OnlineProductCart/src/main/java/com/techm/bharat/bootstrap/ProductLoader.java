package com.techm.bharat.bootstrap;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.techm.bharat.beans.Product;
import com.techm.bharat.repositories.ProductRepository;

@Component
public class ProductLoader implements ApplicationListener<ContextRefreshedEvent> {

    private ProductRepository productRepository;

 	//private Logger log = Logger.getLogger(ProductLoader.class);

    @Autowired
    public void setProductRepository(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {

        Product laptop = new Product();
        laptop.setDescription("Laptop for Apple");
        laptop.setPrice(new BigDecimal("1008.95"));
        laptop.setImageUrl("/static/images/laptop.jpg");
        laptop.setProductId("455554444");
        productRepository.save(laptop);

      
        Product ipad = new Product();
        ipad.setDescription("Ipad for Apple");
        ipad.setImageUrl("/static/images/ipad.jpg");
        ipad.setProductId("343434343");
        ipad.setPrice(new BigDecimal("331.95"));
        productRepository.save(ipad);
        
        
        Product tabs = new Product();
        tabs.setDescription("tabs for Apple and samsung");
        tabs.setImageUrl("/static/images/tab.jpg");
        tabs.setProductId("56565656");
        tabs.setPrice(new BigDecimal("231.95"));
        productRepository.save(tabs);
        
        Product phones = new Product();
        phones.setDescription("phone for Apple and samsung");
        phones.setImageUrl("/static/images/phone.jpg");
        phones.setProductId("223434343");
        phones.setPrice(new BigDecimal("991.95"));
        productRepository.save(phones);
        

    }
}
