package com.techm.bharat.exceptions;

public class CustomSystemException extends RuntimeException{
	public CustomSystemException(String message) {
		super(message);
	}
}
