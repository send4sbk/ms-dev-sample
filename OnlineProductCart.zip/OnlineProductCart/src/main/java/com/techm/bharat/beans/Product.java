package com.techm.bharat.beans;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Version;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Version
    private Integer version;

    
    private String productId;
    
    @NotNull(message="Description could not null, Please enter a description")
    private String description;
    
    @NotNull(message="image url could not be null, Please paste the url")
    private String imageUrl;
    
    @NotNull(message="price could not be null, Please enter a valid price")
    private BigDecimal price;
    private String productName;
   // private List<String> relatedItems;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	/*public List<String> getRelatedItems() {
		return relatedItems;
	}

	public void setRelatedItems(List<String> relatedItems) {
		this.relatedItems = relatedItems;
	}*/

	@Override
	public String toString() {
		return "Product [id=" + id + ", productId=" + productId + ", description="
				+ description + ", imageUrl=" + imageUrl + ", price=" + price + ", productName=" + productName
				 + "]";
	}

	public Product(Integer id, String productId, String description, String imageUrl, BigDecimal price,
			String productName) {
		super();
		this.id = id;
		this.productId = productId;
		this.description = description;
		this.imageUrl = imageUrl;
		this.price = price;
		this.productName = productName;
	}
    public Product() {}
    
}
