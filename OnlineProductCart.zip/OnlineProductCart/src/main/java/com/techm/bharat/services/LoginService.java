package com.techm.bharat.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.techm.bharat.beans.LoginBean;

@Service
public class LoginService {

	private static List<LoginBean> userLst = new ArrayList<LoginBean>();

	static {
		userLst.add(new LoginBean("bharat", "123"));
		userLst.add(new LoginBean("josh", "123"));
	}

	public boolean isValidUser(String userName, String passwd) {

		for (LoginBean bean : userLst) {

			if ((!StringUtils.isEmpty(userName)) && (!StringUtils.isEmpty(passwd))) {
				if (bean.getUserId().equalsIgnoreCase(userName) && bean.getPassword().equalsIgnoreCase(passwd)) {
					return true;
				}
			}
		}
		return false;
	}

}
