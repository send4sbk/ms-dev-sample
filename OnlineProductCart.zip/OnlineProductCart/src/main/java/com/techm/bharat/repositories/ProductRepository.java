package com.techm.bharat.repositories;

import org.springframework.data.repository.CrudRepository;

import com.techm.bharat.beans.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{
}
