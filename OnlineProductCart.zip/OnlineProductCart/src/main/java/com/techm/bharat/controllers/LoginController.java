package com.techm.bharat.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.techm.bharat.beans.LoginBean;
import com.techm.bharat.services.LoginService;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	
	private LoginService loginService;
	private Boolean isValid=false;
	
	@Autowired
	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}
	
	@RequestMapping("/")
    String index(Model model){
		model.addAttribute("loginBean", new LoginBean());
        return "login";
    }
	
	@RequestMapping("/home")
    String home(){
	    return "index";
    }
    
    @RequestMapping(value = "/validateLogin", method = RequestMethod.POST)
	public String validateLogin(LoginBean model) {
    	
    	System.out.println(model.toString());
    	
    	String userName = model.getUserId();
		String password = model.getPassword();
		
		isValid = loginService.isValidUser(userName,password);
 
		if (isValid) {
			
			//ModelAndView homeView = new ModelAndView("home");
			return "index";
		} else {
			//ModelAndView errorView = new ModelAndView("error");
			return "error";
		}
}
}
